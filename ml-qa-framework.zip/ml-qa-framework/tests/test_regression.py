from src.run_experiment import run_regression_experiment


def test_linear_regression_endpoint_quality():
    report = run_regression_experiment("configs/regression_config.json")

    overall_pass = report["validation_result"]["overall_pass"]

    assert overall_pass is True