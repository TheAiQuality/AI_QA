# ML QA Framework - Linear Regression Endpoint Test

This project tests a Linear Regression FastAPI endpoint using a CSV dataset.

## Model Formula

```text
y = 2x + 1
```

## Project Flow

```text
CSV dataset
→ Load dataset
→ Validate dataset
→ Call FastAPI endpoint for each row
→ Collect predictions
→ Calculate metrics
→ Validate thresholds
→ Generate report
→ Run pytest
```

## Dataset

File:

```text
datasets/regression_test.csv
```

Example:

```csv
x,y
1,3
2,5
3,7
```

## API Endpoint

Start API server:

```bash
uvicorn src.endpoint_runner:app --reload
```

Health check:

```text
GET http://127.0.0.1:8000/
```

Prediction endpoint:

```text
POST http://127.0.0.1:8000/predict
```

Request:

```json
{
  "x": 5
}
```

Response:

```json
{
  "x": 5,
  "prediction": 11
}
```

## Install Dependencies

```bash
pip install -r requirements
```

## Run Experiment

In terminal 1:

```bash
uvicorn src.endpoint_runner:app --reload
```

In terminal 2:

```bash
python -m src.run_experiment
```

## Run Pytest

Make sure API server is running first.

```bash
pytest tests/test_regression.py
```

## Report

Report will be generated here:

```text
reports/regression_report.json
```

## Metrics

The framework calculates:

- MAE
- MSE
- RMSE
- R2 Score

## Pass Criteria

```text
MAE <= 0.5
MSE <= 0.5
RMSE <= 0.8
R2 Score >= 0.95
```

## Performance Test

Start FastAPI first:

```bash
uvicorn src.endpoint_runner:app --reload
```

Then run Locust:

```bash
locust -f performance/locustfile.py --host http://127.0.0.1:8000
```