from locust import HttpUser, task, between


class RegressionEndpointUser(HttpUser):
    """
    Locust performance test for Linear Regression prediction endpoint.

    This is used to test:
        - response time
        - request throughput
        - endpoint stability under load

    Before running this, your FastAPI server must be running.
    """

    # Wait 1 to 3 seconds between user requests
    wait_time = between(1, 3)

    @task
    def test_prediction_endpoint(self):
        """
        Send a sample POST request to /predict endpoint.
        """

        # Send request to FastAPI endpoint
        self.client.post(
            "/predict",
            json={
                "x": 5
            }
        )