from fastapi import APIRouter
from pydantic import BaseModel


# Create a router for regression-related endpoints
router = APIRouter()


class PredictionRequest(BaseModel):
    """
    Request body schema.

    Expected request:
    {
        "x": 5
    }
    """

    x: float


class PredictionResponse(BaseModel):
    """
    Response body schema.

    Expected response:
    {
        "x": 5,
        "prediction": 11
    }
    """

    x: float
    prediction: float


def predict_linear_regression(x: float) -> float:
    """
    Simple regression model formula.

    Formula:
        y = 2x + 1
    """

    return 2 * x + 1


@router.get("/")
def health_check():
    """
    Health check route.

    URL:
        GET http://127.0.0.1:8000/
    """

    return {
        "status": "running",
        "message": "Linear Regression API is working"
    }


@router.post("/predict", response_model=PredictionResponse)
def predict(request: PredictionRequest):
    """
    Prediction route.

    URL:
        POST http://127.0.0.1:8000/predict

    Request:
    {
        "x": 5
    }

    Response:
    {
        "x": 5,
        "prediction": 11
    }
    """

    # Get input x from request body
    x_value = request.x

    # Calculate prediction
    predicted_value = predict_linear_regression(x_value)

    # Return JSON response
    return {
        "x": x_value,
        "prediction": predicted_value
    }