from fastapi import FastAPI
from regression_endpoint import router as regression_router


# Create FastAPI app
app = FastAPI(
    title="ML QA Framework API",
    description="API server for ML prediction endpoints",
    version="1.0.0"
)


# Attach regression prediction routes
app.include_router(regression_router)