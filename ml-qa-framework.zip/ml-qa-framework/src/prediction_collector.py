import requests


def collect_predictions_from_endpoint(data, feature_column, endpoint_url):
    """
    Send each row from the dataset to the FastAPI prediction endpoint.

    Important:
        You do not manually hit values one by one.
        This function automatically loops through all rows.

    Parameters:
        data: pandas DataFrame containing test data
        feature_column: input column name, example: "x"
        endpoint_url: FastAPI endpoint URL

    Returns:
        list of predictions from the API
    """

    # Empty list to store all prediction values
    predictions = []

    # Loop through each row in the dataset
    for index, row in data.iterrows():
        # Read input value from current row
        # Example: if feature_column = "x", then get row["x"]
        x_value = row[feature_column]

        # Prepare JSON payload for API request
        # Example:
        # {
        #   "x": 5
        # }
        payload = {
            "x": float(x_value)
        }

        # Send POST request to FastAPI endpoint
        response = requests.post(
            endpoint_url,
            json=payload,
            timeout=10
        )

        # If API response status is not 2xx, raise an error
        # Example: 500, 404, 422 will fail here
        response.raise_for_status()

        # Convert JSON response to Python dictionary
        response_json = response.json()

        # Extract prediction value from response
        # Example response:
        # {
        #   "x": 5,
        #   "prediction": 11
        # }
        prediction = response_json["prediction"]

        # Store prediction in predictions list
        predictions.append(prediction)

    # Return all collected predictions
    return predictions
