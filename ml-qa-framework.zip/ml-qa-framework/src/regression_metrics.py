import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def calculate_regression_metrics(y_true, y_pred):
    """
    Calculate regression performance metrics.

    Parameters:
        y_true: list of actual values from CSV
        y_pred: list of predicted values from API

    Returns:
        dictionary containing MAE, MSE, RMSE, and R2 score
    """

    # Mean Absolute Error
    # Average absolute difference between actual and predicted values
    mae = mean_absolute_error(y_true, y_pred)

    # Mean Squared Error
    # Average squared difference between actual and predicted values
    mse = mean_squared_error(y_true, y_pred)

    # Root Mean Squared Error
    # Square root of MSE
    rmse = np.sqrt(mse)

    # R2 Score
    # Measures how well predictions match actual values
    # Best value is 1.0
    r2 = r2_score(y_true, y_pred)

    # Convert numpy values to normal Python float for JSON report
    return {
        "mae": float(mae),
        "mse": float(mse),
        "rmse": float(rmse),
        "r2_score": float(r2)
    }