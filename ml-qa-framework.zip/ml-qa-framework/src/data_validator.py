import numpy as np


def validate_regression_data(data, feature_columns, target_column):
    """
    Validate regression dataset structure and values.

    This function checks:
        1. Dataset is not empty
        2. Feature columns exist
        3. Target column exists
        4. Feature values are not null
        5. Target values are not null
        6. Feature values are numeric
        7. Target values are numeric
        8. Feature values are finite numbers
        9. Target values are finite numbers

    Parameters:
        data: pandas DataFrame containing test data
        feature_columns: list of input feature column names
        target_column: actual output column name

    Returns:
        bool: True if validation passes

    Raises:
        ValueError: If validation fails
    """

    # Check whether dataset is empty
    if data.empty:
        raise ValueError("Dataset is empty")

    # Check whether each feature column exists in the dataset
    for column in feature_columns:
        if column not in data.columns:
            raise ValueError(f"Missing feature column: {column}")

    # Check whether target column exists in the dataset
    if target_column not in data.columns:
        raise ValueError(f"Missing target column: {target_column}")

    # Combine feature columns and target column for validation
    required_columns = feature_columns + [target_column]

    # Check every required column
    for column in required_columns:

        # Check for missing/null values
        if data[column].isnull().any():
            raise ValueError(f"Column '{column}' contains missing/null values")

        # Check whether column is numeric
        if not np.issubdtype(data[column].dtype, np.number):
            raise ValueError(f"Column '{column}' must contain numeric values")

        # Check whether column contains infinite values
        if np.isinf(data[column]).any():
            raise ValueError(f"Column '{column}' contains infinite values")

    # If all validations pass, return True
    return True
