import json
import logging
import os

from src.dataset_loader import load_dataset
from src.data_validator import validate_regression_data
from src.prediction_collector import collect_predictions_from_endpoint
from src.regression_metrics import calculate_regression_metrics
from src.threshold_validator import validate_regression_thresholds
from src.report_generator import generate_report


def run_regression_experiment(config_path):
    """
    Run the complete Linear Regression endpoint QA experiment.

    Full flow:
        1. Load config
        2. Load CSV dataset
        3. Validate dataset
        4. Call FastAPI endpoint for every row
        5. Collect predictions
        6. Compare predictions with actual values
        7. Calculate metrics
        8. Validate thresholds
        9. Generate report
        10. Return final result

    Parameters:
        config_path: path to regression config JSON file

    Returns:
        dictionary containing final report data
    """

    # Create logs folder if it does not exist
    os.makedirs("logs", exist_ok=True)

    # Configure logging
    logging.basicConfig(
        filename="logs/execution.log",
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        force=True
    )

    logging.info("Regression endpoint experiment started")

    # Load config JSON file
    with open(config_path, "r") as file:
        config = json.load(file)

    # Extract values from config
    experiment_name = config["experiment_name"]
    dataset_path = config["dataset_path"]
    target_column = config["target_column"]
    feature_columns = config["feature_columns"]
    endpoint_url = config["endpoint_url"]
    thresholds = config["thresholds"]
    report_path = config["report_path"]

    logging.info(f"Experiment name: {experiment_name}")
    logging.info(f"Dataset path: {dataset_path}")
    logging.info(f"Endpoint URL: {endpoint_url}")

    # Load dataset from CSV
    data = load_dataset(dataset_path)

    logging.info(f"Dataset loaded successfully with {len(data)} rows")

    # Validate dataset structure and values
    validate_regression_data(
        data=data,
        feature_columns=feature_columns,
        target_column=target_column
    )

    logging.info("Dataset validation completed successfully")

    # This simple example uses only one feature column: x
    feature_column = feature_columns[0]

    # Call endpoint for each row and collect predictions
    predictions = collect_predictions_from_endpoint(
        data=data,
        feature_column=feature_column,
        endpoint_url=endpoint_url
    )

    logging.info("Predictions collected successfully from endpoint")

    # Extract actual expected values from dataset
    actual_values = data[target_column].tolist()

    # Calculate regression metrics
    metrics = calculate_regression_metrics(
        y_true=actual_values,
        y_pred=predictions
    )

    logging.info(f"Metrics calculated: {metrics}")

    # Validate metrics against thresholds
    validation_result = validate_regression_thresholds(
        metrics=metrics,
        thresholds=thresholds
    )

    logging.info(f"Validation result: {validation_result}")

    # Create final report dictionary
    report_data = {
        "experiment_name": experiment_name,
        "dataset_path": dataset_path,
        "endpoint_url": endpoint_url,
        "target_column": target_column,
        "feature_columns": feature_columns,
        "actual_values": actual_values,
        "predicted_values": predictions,
        "metrics": metrics,
        "thresholds": thresholds,
        "validation_result": validation_result
    }

    # Save report to JSON file
    generate_report(
        report_path=report_path,
        report_data=report_data
    )

    logging.info(f"Report generated at: {report_path}")
    logging.info(f"Overall pass: {validation_result['overall_pass']}")
    logging.info("Regression endpoint experiment completed")

    # Return report data to pytest or command line
    return report_data


if __name__ == "__main__":
    """
    This block runs only when you execute:

        python -m src.run_experiment
    """

    # Run the experiment using config file
    result = run_regression_experiment(
        r"C:\FastAPI\AI\AI_QA_Framework\QA_Framework\Simple_Framework\ml-qa-framework\configs\regression_config.json"
    )

    # Print formatted result in terminal
    print(json.dumps(result, indent=4))