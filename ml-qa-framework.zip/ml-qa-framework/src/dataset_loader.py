import pandas as pd


def load_dataset(dataset_path):
    """
    Load dataset from a CSV file.

    Parameters:
        dataset_path (str): Path to the CSV dataset.

    Returns:
        pandas.DataFrame: Loaded dataset.
    """

    # Read the CSV file using pandas
    data = pd.read_csv(dataset_path)

    # Return the loaded dataframe
    return data
