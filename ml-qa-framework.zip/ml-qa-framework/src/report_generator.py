import json
import os


def generate_report(report_path, report_data):
    """
    Generate JSON report for the QA experiment.

    Parameters:
        report_path: output file path
        report_data: dictionary containing final experiment result

    Returns:
        None
    """

    # Get report folder path from report file path
    # Example:
    # report_path = "reports/regression_report.json"
    # os.path.dir name(report_path) = "reports"
    reports = os.path.dirname(report_path)

    # Create reports folder if it does not exist
    os.makedirs(reports, exist_ok=True)

    # Write report data into JSON file
    with open(report_path, "w") as file:
        json.dump(report_data, file, indent=4)
