def validate_regression_thresholds(metrics, thresholds):
    """
    Validate calculated regression metrics against configured thresholds.

    Parameters:
        metrics: calculated metric values
        thresholds: allowed threshold values from config

    Returns:
        dictionary containing pass/fail result for each metric
    """

    # MAE should be less than or equal to configured threshold
    mae_pass = metrics["mae"] <= thresholds["mae"]

    # MSE should be less than or equal to configured threshold
    mse_pass = metrics["mse"] <= thresholds["mse"]

    # RMSE should be less than or equal to configured threshold
    rmse_pass = metrics["rmse"] <= thresholds["rmse"]

    # R2 score should be greater than or equal to configured threshold
    r2_pass = metrics["r2_score"] >= thresholds["r2_score"]

    # Overall test passes only if all metric checks pass
    overall_pass = mae_pass and mse_pass and rmse_pass and r2_pass

    # Return detailed validation result
    return {
        "mae_pass": mae_pass,
        "mse_pass": mse_pass,
        "rmse_pass": rmse_pass,
        "r2_score_pass": r2_pass,
        "overall_pass": overall_pass
    }